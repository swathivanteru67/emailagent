"""
app.py — Streamlit dashboard for Email-to-ServiceNow agent
Run with: streamlit run app.py
"""

import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime
import time

import agent  # our backend

# ── Page config ───────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="TicketIQ — Email Agent",
    page_icon="🎫",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── CSS ───────────────────────────────────────────────────────────────────────
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;600&family=IBM+Plex+Sans:wght@300;400;500;600;700&display=swap');

:root {
    --bg:          #0d1117;
    --bg2:         #161b22;
    --bg3:         #21262d;
    --border:      #30363d;
    --text:        #e6edf3;
    --muted:       #7d8590;
    --accent:      #58a6ff;
    --accent2:     #bc8cff;
    --green:       #3fb950;
    --yellow:      #d29922;
    --red:         #f85149;
    --orange:      #f0883e;
    --font:        'IBM Plex Sans', sans-serif;
    --mono:        'IBM Plex Mono', monospace;
}

html, body, [class*="css"] {
    font-family: var(--font) !important;
    background-color: var(--bg) !important;
    color: var(--text) !important;
}

#MainMenu, footer, header { visibility: hidden !important; }
.block-container { padding: 1.5rem 2rem 3rem !important; max-width: 1400px !important; }

/* Sidebar */
[data-testid="stSidebar"] {
    background: var(--bg2) !important;
    border-right: 1px solid var(--border) !important;
}

/* Metrics */
[data-testid="stMetric"] {
    background: var(--bg2) !important;
    border: 1px solid var(--border) !important;
    border-radius: 10px !important;
    padding: 16px 20px !important;
}
[data-testid="stMetricLabel"] { color: var(--muted) !important; font-size: 11px !important; text-transform: uppercase; letter-spacing: .8px; }
[data-testid="stMetricValue"] { color: var(--text) !important; font-family: var(--mono) !important; font-size: 28px !important; }
[data-testid="stMetricDelta"] { font-size: 12px !important; }

/* Buttons */
.stButton > button {
    background: var(--bg3) !important;
    color: var(--text) !important;
    border: 1px solid var(--border) !important;
    border-radius: 6px !important;
    font-family: var(--font) !important;
    font-size: 13px !important;
    font-weight: 500 !important;
    padding: 8px 16px !important;
    transition: all .15s !important;
}
.stButton > button:hover {
    border-color: var(--accent) !important;
    color: var(--accent) !important;
}

/* Tables */
[data-testid="stDataFrame"] { border: 1px solid var(--border) !important; border-radius: 8px !important; }

/* Tabs */
[data-testid="stTabs"] button {
    font-family: var(--font) !important;
    font-size: 13px !important;
    color: var(--muted) !important;
}
[data-testid="stTabs"] button[aria-selected="true"] {
    color: var(--text) !important;
    border-bottom-color: var(--accent) !important;
}

/* Alerts */
[data-testid="stAlert"] { border-radius: 8px !important; font-size: 13px !important; }

/* Log entries */
.log-entry { font-family: var(--mono); font-size: 11px; padding: 3px 0; border-bottom: 1px solid var(--border); }
.log-info    { color: var(--muted); }
.log-warning { color: var(--yellow); }
.log-error   { color: var(--red); }

/* Priority badges */
.badge {
    display: inline-block; padding: 2px 10px; border-radius: 20px;
    font-size: 11px; font-weight: 600; font-family: var(--mono);
}
.badge-Critical { background: #3d1a1a; color: var(--red);    border: 1px solid var(--red); }
.badge-High     { background: #2d1f0e; color: var(--orange); border: 1px solid var(--orange); }
.badge-Medium   { background: #2d2500; color: var(--yellow); border: 1px solid var(--yellow); }
.badge-Low      { background: #0d2318; color: var(--green);  border: 1px solid var(--green); }

/* Ticket card */
.ticket-card {
    background: var(--bg2); border: 1px solid var(--border);
    border-radius: 10px; padding: 16px 18px; margin-bottom: 10px;
}
.ticket-card:hover { border-color: var(--accent); }
.ticket-id    { font-family: var(--mono); font-size: 12px; color: var(--accent); font-weight: 600; }
.ticket-title { font-size: 14px; font-weight: 600; color: var(--text); margin: 4px 0; }
.ticket-meta  { font-size: 11px; color: var(--muted); }

/* Header */
.topbar {
    display: flex; align-items: center; justify-content: space-between;
    padding: 12px 0 20px; border-bottom: 1px solid var(--border); margin-bottom: 24px;
}
.tb-title { font-size: 20px; font-weight: 700; color: var(--text); letter-spacing: -.4px; }
.tb-sub   { font-size: 12px; color: var(--muted); margin-top: 2px; }
.pulse {
    display: inline-block; width: 8px; height: 8px; border-radius: 50%;
    background: var(--green); margin-right: 6px;
    animation: pulse 2s infinite;
}
@keyframes pulse {
    0%,100% { box-shadow: 0 0 0 0 rgba(63,185,80,.4); }
    50%      { box-shadow: 0 0 0 6px rgba(63,185,80,0); }
}
.status-badge {
    display: inline-flex; align-items: center;
    background: #0d2318; border: 1px solid var(--green);
    border-radius: 20px; padding: 5px 14px;
    font-size: 12px; font-weight: 500; color: var(--green);
}
.status-stopped {
    background: #1a1a1a; border-color: var(--muted);
    color: var(--muted);
}

/* Cross-thread follow-up badge */
.xthread-badge {
    display: inline-block; padding: 2px 10px; border-radius: 20px;
    font-size: 11px; font-weight: 600; font-family: var(--mono);
    background: #1a1f2e; color: #58a6ff; border: 1px solid #2d5a9e;
}

/* Section header */
.sec-hd {
    font-size: 11px; font-weight: 600; color: var(--muted);
    text-transform: uppercase; letter-spacing: .8px;
    margin-bottom: 12px; padding-bottom: 8px;
    border-bottom: 1px solid var(--border);
}

hr { border: none !important; border-top: 1px solid var(--border) !important; margin: 16px 0 !important; }
</style>
""", unsafe_allow_html=True)


# ── Session state ─────────────────────────────────────────────────────────────
if "scheduler_started" not in st.session_state:
    st.session_state["scheduler_started"] = False
if "auto_refresh" not in st.session_state:
    st.session_state["auto_refresh"] = True


# ── Sidebar ───────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("""
    <div style="padding:18px 0 14px">
        <div style="font-size:22px;font-weight:700;color:#e6edf3;letter-spacing:-.5px">🎫 TicketIQ</div>
        <div style="font-size:11px;color:#7d8590;margin-top:2px">Email → ServiceNow Agent</div>
    </div>
    <hr>
    """, unsafe_allow_html=True)

    st.markdown('<div class="sec-hd">⚙️ Scheduler Control</div>', unsafe_allow_html=True)

    state = agent.get_state()
    running = state["scheduler_running"]

    if not running:
        if st.button("▶  Start Agent", key="start_btn", width="stretch"):
            agent.start_scheduler()
            st.session_state["scheduler_started"] = True
            st.rerun()
    else:
        if st.button("⏹  Stop Agent", key="stop_btn", width="stretch"):
            agent.stop_scheduler()
            st.rerun()

    if st.button("⚡ Check Now", key="manual_btn", width="stretch"):
        agent.trigger_now()
        st.toast("Checking emails now…", icon="⚡")

    st.markdown('<hr>', unsafe_allow_html=True)
    st.markdown('<div class="sec-hd">🔄 Display</div>', unsafe_allow_html=True)

    auto = st.toggle("Auto-refresh (30s)", value=st.session_state["auto_refresh"])
    st.session_state["auto_refresh"] = auto

    poll_info = f"Poll interval: {agent.POLL_INTERVAL_SECS}s"
    last = state.get("last_checked")
    st.markdown(f"""
    <div style="font-size:11px;color:#7d8590;margin-top:8px">
        {poll_info}<br>
        Last check: {last or 'Not yet'}
    </div>
    """, unsafe_allow_html=True)

    st.markdown('<hr>', unsafe_allow_html=True)
    st.markdown('<div class="sec-hd">📊 Session Stats</div>', unsafe_allow_html=True)
    stats = state["stats"]
    for label, val, color in [
        ("Emails processed", stats["total_emails"],         "#58a6ff"),
        ("Tickets created",  stats["tickets_created"],      "#3fb950"),
        ("Followups",        stats.get("followups", 0),     "#bc8cff"),
        ("No action",        stats["no_action"],            "#7d8590"),
        ("Errors",           stats["errors"],               "#f85149"),
    ]:
        st.markdown(f"""
        <div style="display:flex;justify-content:space-between;align-items:center;
                    padding:7px 10px;margin-bottom:5px;background:#21262d;
                    border-radius:7px;border:1px solid #30363d;">
            <span style="font-size:12px;color:#7d8590">{label}</span>
            <span style="font-family:'IBM Plex Mono';font-size:14px;font-weight:600;color:{color}">{val}</span>
        </div>
        """, unsafe_allow_html=True)


# ── Main area ─────────────────────────────────────────────────────────────────
state   = agent.get_state()
tickets = state["tickets"]
running = state["scheduler_running"]

# Topbar
status_cls  = "status-badge" if running else "status-badge status-stopped"
status_text = "Agent Running" if running else "Agent Stopped"
pulse_html  = '<span class="pulse"></span>' if running else "⏹ "

st.markdown(f"""
<div class="topbar">
    <div>
        <div class="tb-title">Email → ServiceNow Dashboard</div>
        <div class="tb-sub">AI-powered IT ticket creation · NVIDIA · Gmail</div>
    </div>
    <div class="{status_cls}">{pulse_html}{status_text}</div>
</div>
""", unsafe_allow_html=True)

# ── Top metrics ───────────────────────────────────────────────────────────────
c1, c2, c3, c4, c5 = st.columns(5)
stats = state["stats"]
c1.metric("Total Emails",    stats["total_emails"])
c2.metric("Tickets Created", stats["tickets_created"])
c3.metric("Followups",       stats.get("followups", 0))
c4.metric("No Action",       stats["no_action"])
c5.metric("Errors",          stats["errors"])

st.markdown("<br>", unsafe_allow_html=True)

# ── Tabs ──────────────────────────────────────────────────────────────────────
tab_tickets, tab_charts, tab_logs, tab_db = st.tabs(["🎫 Tickets", "📊 Analytics", "📋 Logs", "🗄️ Database"])


# ══════════════════ TICKETS TAB ══════════════════════════════════════════════
with tab_tickets:
    col_filter, col_spacer = st.columns([3, 1])
    with col_filter:
        filter_priority = st.multiselect(
            "Filter by priority",
            ["Critical", "High", "Medium", "Low"],
            default=[],
            placeholder="All priorities",
        )
        filter_category = st.multiselect(
            "Filter by category",
            ["Hardware", "Software", "Network", "Access", "Other"],
            default=[],
            placeholder="All categories",
        )

    filtered = tickets
    if filter_priority:
        filtered = [t for t in filtered if t.get("priority") in filter_priority]
    if filter_category:
        filtered = [t for t in filtered if t.get("category") in filter_category]

    if not filtered:
        st.markdown("""
        <div style="text-align:center;padding:60px 20px;background:#161b22;
                    border:2px dashed #30363d;border-radius:12px;margin-top:16px;">
            <div style="font-size:36px;margin-bottom:12px">🎫</div>
            <div style="font-size:16px;font-weight:600;color:#e6edf3">No tickets yet</div>
            <div style="font-size:13px;color:#7d8590;margin-top:6px">
                Start the agent and incoming support emails will appear here automatically.
            </div>
        </div>
        """, unsafe_allow_html=True)
    else:
        st.markdown(f'<div style="font-size:12px;color:#7d8590;margin-bottom:12px">{len(filtered)} ticket(s)</div>', unsafe_allow_html=True)

        for t in filtered:
            priority  = t.get("priority", "Medium")
            category  = t.get("category", "Other")
            sn_status = t.get("sn_status", "")
            sn_badge  = "🟢 Created" if sn_status == "created" else "🟡 Mock" if sn_status == "mock" else "🔴 Error"

            reply_count = t.get("thread_reply_count", 0)
            xthread_count = 0
            reply_word  = "reply" if reply_count == 1 else "replies"
            if reply_count > 0:
                reply_badge = (
                    '<span style="font-size:11px;background:#1a2a1a;color:#3fb950;'
                    'border:1px solid #3fb950;border-radius:12px;padding:2px 8px;'
                    'font-family:IBM Plex Mono">'
                    + f"🔁 {reply_count} {reply_word}" +
                    '</span>'
                )
            else:
                reply_badge = ""

            # ── Ticket summary card (no body crammed inside) ─────────────────
            tid     = t.get("id", "—")
            summary = t.get("summary", "(no summary)")
            sender  = t.get("sender", "")
            created = t.get("created_at", "")

            card_html = (
                '<div class="ticket-card">'
                '<div style="display:flex;justify-content:space-between;align-items:flex-start">'
                '<div style="flex:1;min-width:0">'
                '<div style="display:flex;align-items:center;gap:8px;margin-bottom:4px;flex-wrap:wrap">'
                '<span class="ticket-id">' + tid + '</span>' + reply_badge +
                '</div>'
                '<div class="ticket-title" style="margin-bottom:6px">' + summary + '</div>'
                '<div class="ticket-meta">'
                '📧 ' + sender + ' &nbsp;·&nbsp; '
                '🗂 ' + category + ' &nbsp;·&nbsp; '
                '🕐 ' + created + ' &nbsp;·&nbsp; ' + sn_badge +
                '</div>'
                '</div>'
                '<span class="badge badge-' + priority + '" style="margin-left:12px;flex-shrink:0">'
                + priority + '</span>'
                '</div>'
                '</div>'
            )

            # Append a subtle last-reply bar at the bottom of the card if follow-ups exist
            last_at  = t.get("last_reply_at", "") or ""
            last_sub = t.get("last_reply_subject", "") or ""
            if last_at:
                card_html += (
                    '<div style="margin-top:8px;padding:6px 10px;background:#1a1230;'
                    'border:1px solid #3d2b5e;border-radius:6px;font-size:11px;'
                    'font-family:IBM Plex Mono;color:#bc8cff">'
                    '🔁 Last follow-up: ' + last_at + ' &nbsp;·&nbsp; ' + last_sub +
                    '</div>'
                )

            # ── Related incidents inline recommendation banner ────────────
            related_list = t.get("related_incidents") or []
            if related_list:
                top_rel = related_list[0]
                top_score = int(top_rel.get("similarity_score", 0) * 100)
                top_id    = top_rel.get("id", "—")
                top_sum   = top_rel.get("summary", "")[:80]
                top_reason = top_rel.get("similarity_reason", "")[:100]
                score_color = "#3fb950" if top_score >= 60 else "#d29922" if top_score >= 35 else "#7d8590"
                score_bg    = "#0d2318" if top_score >= 60 else "#2d2500" if top_score >= 35 else "#21262d"
                more_txt    = f" +{len(related_list)-1} more" if len(related_list) > 1 else ""
                card_html += (
                    '<div style="margin-top:8px;padding:8px 12px;background:#0d1a2e;'
                    'border:1px solid #1f4068;border-radius:6px;font-size:11px;'
                    'display:flex;align-items:flex-start;gap:8px;">'
                    '<span style="color:#58a6ff;font-size:13px;flex-shrink:0">💡</span>'
                    '<div style="flex:1;min-width:0">'
                    '<span style="color:#58a6ff;font-weight:600">Related incident' + more_txt + ': </span>'
                    '<span style="font-family:IBM Plex Mono;color:#58a6ff">' + top_id + '</span>'
                    '<span style="color:#7d8590"> · ' + top_sum + ('…' if len(top_rel.get("summary","")) > 80 else '') + '</span>'
                    + ('<br><span style="color:#7d8590;font-style:italic">' + top_reason + '</span>' if top_reason else '') +
                    '</div>'
                    '<span style="font-size:10px;font-family:IBM Plex Mono;font-weight:700;'
                    'padding:2px 7px;border-radius:10px;flex-shrink:0;'
                    'border:1px solid ' + score_color + ';'
                    'color:' + score_color + ';'
                    'background:' + score_bg + '">'
                    + f'{top_score}%</span>'
                    '</div>'
                )

            st.markdown(card_html, unsafe_allow_html=True)

            # ── Ticket detail expander — correctly placed BELOW the card ─────
            with st.expander(f"🔍 Details — {tid}", expanded=False):
                det_col1, det_col2 = st.columns([2, 1])

                with det_col1:
                    st.markdown("**📝 Description**")
                    desc_text = t.get("description", "(none)") or "(none)"
                    st.markdown(
                        '<div style="font-size:13px;color:#c9d1d9;background:#0d1117;'
                        'padding:12px 14px;border-radius:6px;border:1px solid #30363d;'
                        'font-family:IBM Plex Mono;line-height:1.7;white-space:pre-wrap">'
                        + desc_text + '</div>',
                        unsafe_allow_html=True,
                    )
                    st.markdown("<br>", unsafe_allow_html=True)
                    st.markdown("**📧 Email preview**")
                    preview_text = t.get("body_preview", "") or ""
                    preview_disp = preview_text[:400] + ("…" if len(preview_text) > 400 else "")
                    st.markdown(
                        '<div style="font-size:12px;color:#7d8590;background:#0d1117;'
                        'padding:10px 12px;border-radius:6px;border:1px solid #30363d;'
                        'font-family:IBM Plex Mono;line-height:1.6;white-space:pre-wrap">'
                        + preview_disp + '</div>',
                        unsafe_allow_html=True,
                    )

                    # Show latest follow-up reply if there is one
                    last_reply_preview = t.get("last_reply_preview", "") or ""
                    if last_reply_preview:
                        st.markdown("<br>", unsafe_allow_html=True)
                        last_reply_at_lbl = t.get("last_reply_at", "") or ""
                        last_reply_sub_lbl = t.get("last_reply_subject", "") or ""
                        st.markdown(
                            f"**🔁 Latest follow-up** "
                            f"<span style='font-size:11px;color:#7d8590'>"
                            f"&nbsp;·&nbsp; {last_reply_at_lbl} &nbsp;·&nbsp; {last_reply_sub_lbl}"
                            f"</span>",
                            unsafe_allow_html=True,
                        )
                        followup_disp = last_reply_preview[:400] + ("…" if len(last_reply_preview) > 400 else "")
                        st.markdown(
                            '<div style="font-size:12px;color:#bc8cff;background:#0d1117;'
                            'padding:10px 12px;border-radius:6px;border:1px solid #3d2b5e;'
                            'font-family:IBM Plex Mono;line-height:1.6;white-space:pre-wrap">'
                            + followup_disp + '</div>',
                            unsafe_allow_html=True,
                        )

                with det_col2:
                    st.markdown("**🏷️ Ticket metadata**")
                    thread_id_short = (t.get("gmail_thread_id") or "—")[:20]
                    last_reply_at  = t.get("last_reply_at", "") or "—"
                    last_reply_sub = t.get("last_reply_subject", "") or "—"
                    meta_items = [
                        ("Ticket #",       tid),
                        ("SN sys_id",      t.get("sys_id", "—") or "—"),
                        ("Priority",       priority),
                        ("Category",       category),
                        ("Customer",       t.get("customer", "—") or "—"),
                        ("SN Status",      sn_status or "—"),
                        ("Replies",        str(reply_count)),
                        ("Last reply at",  last_reply_at),
                        ("Last subject",   last_reply_sub[:28] + ("…" if len(last_reply_sub) > 28 else "")),
                        ("Created",        created),
                        ("Gmail Thread",   thread_id_short),
                    ]
                    for label, val in meta_items:
                        st.markdown(
                            '<div style="display:flex;justify-content:space-between;'
                            'padding:5px 8px;margin-bottom:3px;background:#21262d;'
                            'border-radius:5px;border:1px solid #30363d;">'
                            '<span style="font-size:11px;color:#7d8590">' + label + '</span>'
                            '<span style="font-size:11px;font-family:IBM Plex Mono;'
                            'color:#e6edf3;font-weight:600">' + str(val) + '</span>'
                            '</div>',
                            unsafe_allow_html=True,
                        )

                # ── Related Incidents ──────────────────────────────────────────
                st.markdown("<br>", unsafe_allow_html=True)
                _rel_stored = t.get("related_incidents") or []
                _rel_count  = len(_rel_stored)
                _rel_label  = (
                    f"🔗 Related Incidents &nbsp;"
                    f'<span style="background:#1f4068;color:#58a6ff;font-family:IBM Plex Mono;'
                    f'font-size:11px;padding:1px 8px;border-radius:10px;border:1px solid #2d5a9e">'
                    f'{_rel_count} found</span>'
                    if _rel_count else "🔗 Related Incidents"
                )
                st.markdown(
                    f'<div style="font-size:11px;font-weight:600;color:#7d8590;'
                    f'text-transform:uppercase;letter-spacing:.8px;padding-bottom:8px;'
                    f'border-bottom:1px solid #30363d;margin-bottom:12px">'
                    f'{_rel_label}</div>',
                    unsafe_allow_html=True,
                )

                if _rel_count == 0:
                    st.markdown(
                        '<div style="font-size:12px;color:#7d8590;background:#0d1117;'
                        'border:1px dashed #30363d;border-radius:8px;padding:14px;'
                        'text-align:center">🔍 No related incidents found</div>',
                        unsafe_allow_html=True,
                    )
                else:
                    related = agent.find_related_tickets(t)
                    st.markdown(
                        f'<div style="font-size:12px;color:#58a6ff;margin-bottom:10px">'
                        f'💡 {len(related)} related incident(s) — check these before opening a duplicate</div>',
                        unsafe_allow_html=True,
                    )
                    for rel in related:
                            score      = rel.get("similarity_score", 0)
                            score_pct  = int(score * 100)
                            rel_id     = rel.get("id", "—")
                            rel_sum    = rel.get("summary", "(no summary)")
                            rel_pri    = rel.get("priority", "Medium")
                            rel_cat    = rel.get("category", "Other")
                            rel_sender = rel.get("sender", "")
                            rel_date   = rel.get("created_at", "")
                            rel_status = rel.get("sn_status", "")
                            rel_sn_badge = (
                                "🟢 Created" if rel_status == "created"
                                else "🟡 Mock" if rel_status == "mock"
                                else "🔴 Error"
                            )

                            # Score colour: green ≥60%, yellow ≥35%, else muted
                            score_color = (
                                "#3fb950" if score_pct >= 60
                                else "#d29922" if score_pct >= 35
                                else "#7d8590"
                            )
                            score_bg = (
                                "#0d2318" if score_pct >= 60
                                else "#2d2500" if score_pct >= 35
                                else "#21262d"
                            )

                            # Related ticket card
                            st.markdown(
                                '<div style="background:#0d1117;border:1px solid #30363d;'
                                'border-radius:8px;padding:12px 14px;margin-bottom:6px;">'

                                # Header row: id + score badge
                                '<div style="display:flex;justify-content:space-between;'
                                'align-items:center;margin-bottom:6px">'
                                '<span style="font-family:IBM Plex Mono;font-size:12px;'
                                'color:#58a6ff;font-weight:600">' + rel_id + '</span>'
                                '<span style="font-size:11px;font-family:IBM Plex Mono;'
                                'font-weight:700;padding:2px 9px;border-radius:12px;'
                                'border:1px solid ' + score_color + ';'
                                'color:' + score_color + ';'
                                'background:' + score_bg + '">'
                                + f'{score_pct}% match</span>'
                                '</div>'

                                # Similarity reason (from LLM)
                                + ('<div style="font-size:11px;color:#58a6ff;margin-bottom:4px;font-style:italic">' +
                                   rel.get('similarity_reason', '') + '</div>'
                                   if rel.get('similarity_reason') else '') +

                                # Summary
                                '<div style="font-size:13px;font-weight:600;color:#e6edf3;'
                                'margin-bottom:6px">' + rel_sum + '</div>'

                                # Meta row
                                '<div style="font-size:11px;color:#7d8590">'
                                '📧 ' + rel_sender + ' &nbsp;·&nbsp; '
                                '🗂 ' + rel_cat + ' &nbsp;·&nbsp; '
                                '🕐 ' + rel_date + ' &nbsp;·&nbsp; '
                                + rel_sn_badge + ' &nbsp;·&nbsp; '
                                '<span class="badge badge-' + rel_pri + '">' + rel_pri + '</span>'
                                '</div>'
                                '</div>',
                                unsafe_allow_html=True,
                            )

                            # Drill-down expander for this related ticket
                            with st.expander(f"📄 Full details — {rel_id}", expanded=False):
                                rd_col1, rd_col2 = st.columns([2, 1])

                                with rd_col1:
                                    st.markdown("**📝 Description**")
                                    rel_desc = rel.get("description", "(none)") or "(none)"
                                    st.markdown(
                                        '<div style="font-size:12px;color:#c9d1d9;background:#161b22;'
                                        'padding:10px 12px;border-radius:6px;border:1px solid #30363d;'
                                        'font-family:IBM Plex Mono;line-height:1.7;white-space:pre-wrap">'
                                        + rel_desc + '</div>',
                                        unsafe_allow_html=True,
                                    )
                                    st.markdown("<br>", unsafe_allow_html=True)
                                    st.markdown("**📧 Email preview**")
                                    rel_preview = (rel.get("body_preview", "") or "")[:400]
                                    rel_preview += "…" if len(rel.get("body_preview", "") or "") > 400 else ""
                                    st.markdown(
                                        '<div style="font-size:12px;color:#7d8590;background:#161b22;'
                                        'padding:10px 12px;border-radius:6px;border:1px solid #30363d;'
                                        'font-family:IBM Plex Mono;line-height:1.6;white-space:pre-wrap">'
                                        + rel_preview + '</div>',
                                        unsafe_allow_html=True,
                                    )

                                with rd_col2:
                                    st.markdown("**🏷️ Metadata**")
                                    rel_thread = (rel.get("gmail_thread_id") or "—")[:20]
                                    rel_meta = [
                                        ("Ticket #",     rel_id),
                                        ("SN sys_id",    rel.get("sys_id", "—") or "—"),
                                        ("Priority",     rel_pri),
                                        ("Category",     rel_cat),
                                        ("Customer",     rel.get("customer", "—") or "—"),
                                        ("SN Status",    rel_status or "—"),
                                        ("Replies",      str(rel.get("thread_reply_count", 0))),
                                        ("Created",      rel_date),
                                        ("Similarity",   f"{score_pct}%"),
                                        ("Gmail Thread", rel_thread),
                                    ]
                                    for lbl, val in rel_meta:
                                        st.markdown(
                                            '<div style="display:flex;justify-content:space-between;'
                                            'padding:4px 8px;margin-bottom:3px;background:#21262d;'
                                            'border-radius:5px;border:1px solid #30363d;">'
                                            '<span style="font-size:11px;color:#7d8590">' + lbl + '</span>'
                                            '<span style="font-size:11px;font-family:IBM Plex Mono;'
                                            'color:#e6edf3;font-weight:600">' + str(val) + '</span>'
                                            '</div>',
                                            unsafe_allow_html=True,
                                        )

        # Table view
        with st.expander("📋 Table view"):
            available_cols = [c for c in ["id","summary","priority","category","sender",
                                            "created_at","sn_status","thread_reply_count"] 
                                  if c in pd.DataFrame(filtered).columns]
            df = pd.DataFrame(filtered)[available_cols]
            df.columns = ["Ticket #","Summary","Priority","Category","From","Created","SN Status","Replies"][:len(available_cols)]
            st.dataframe(df, width="stretch", hide_index=True)


# ══════════════════ ANALYTICS TAB ════════════════════════════════════════════
with tab_charts:
    if not tickets:
        st.info("No data yet — start the agent to see analytics.")
    else:
        df_all = pd.DataFrame(tickets)

        chart_col1, chart_col2 = st.columns(2)

        # Priority distribution
        with chart_col1:
            st.markdown('<div class="sec-hd">Tickets by Priority</div>', unsafe_allow_html=True)
            priority_counts = df_all["priority"].value_counts().reset_index()
            priority_counts.columns = ["Priority", "Count"]
            color_map = {"Critical": "#f85149", "High": "#f0883e", "Medium": "#d29922", "Low": "#3fb950"}
            fig1 = px.bar(
                priority_counts, x="Priority", y="Count",
                color="Priority", color_discrete_map=color_map,
                template="plotly_dark",
            )
            fig1.update_layout(
                paper_bgcolor="#161b22", plot_bgcolor="#161b22",
                showlegend=False, margin=dict(l=0, r=0, t=10, b=0),
                font=dict(family="IBM Plex Sans"),
            )
            fig1.update_traces(marker_line_width=0)
            st.plotly_chart(fig1, width="stretch")

        # Category distribution
        with chart_col2:
            st.markdown('<div class="sec-hd">Tickets by Category</div>', unsafe_allow_html=True)
            cat_counts = df_all["category"].value_counts().reset_index()
            cat_counts.columns = ["Category", "Count"]
            fig2 = px.pie(
                cat_counts, names="Category", values="Count",
                template="plotly_dark",
                color_discrete_sequence=["#58a6ff", "#bc8cff", "#3fb950", "#f0883e", "#d29922"],
                hole=0.5,
            )
            fig2.update_layout(
                paper_bgcolor="#161b22", plot_bgcolor="#161b22",
                margin=dict(l=0, r=0, t=10, b=0),
                font=dict(family="IBM Plex Sans"),
            )
            st.plotly_chart(fig2, width="stretch")

        # Timeline
        st.markdown('<div class="sec-hd">Ticket Volume Over Time</div>', unsafe_allow_html=True)
        if "created_at" in df_all.columns:
            df_all["created_dt"] = pd.to_datetime(df_all["created_at"], errors="coerce")
            df_all["minute"]     = df_all["created_dt"].dt.floor("T")
            timeline = df_all.groupby("minute").size().reset_index(name="Count")
            fig3 = px.line(
                timeline, x="minute", y="Count",
                template="plotly_dark", markers=True,
                labels={"minute": "Time", "Count": "Tickets"},
            )
            fig3.update_layout(
                paper_bgcolor="#161b22", plot_bgcolor="#161b22",
                margin=dict(l=0, r=0, t=10, b=0),
                font=dict(family="IBM Plex Sans"),
            )
            fig3.update_traces(line_color="#58a6ff", marker_color="#58a6ff")
            st.plotly_chart(fig3, width="stretch")

        # Priority × Category heatmap
        if len(df_all) >= 3:
            st.markdown('<div class="sec-hd">Priority × Category Heatmap</div>', unsafe_allow_html=True)
            heatmap_data = df_all.groupby(["priority", "category"]).size().reset_index(name="count")
            pivot = heatmap_data.pivot(index="priority", columns="category", values="count").fillna(0)
            fig4 = go.Figure(data=go.Heatmap(
                z=pivot.values, x=list(pivot.columns), y=list(pivot.index),
                colorscale=[[0, "#161b22"], [1, "#58a6ff"]],
                showscale=True,
            ))
            fig4.update_layout(
                paper_bgcolor="#161b22", plot_bgcolor="#161b22",
                margin=dict(l=0, r=0, t=10, b=0),
                font=dict(family="IBM Plex Sans", color="#e6edf3"),
            )
            st.plotly_chart(fig4, width="stretch")


# ══════════════════ LOGS TAB ═════════════════════════════════════════════════
with tab_logs:
    st.markdown('<div class="sec-hd">Agent Activity Log</div>', unsafe_allow_html=True)

    logs = state.get("logs", [])
    if not logs:
        st.info("No logs yet — start the agent.")
    else:
        log_html = ""
        for entry in logs:
            css = f"log-{entry.get('level', 'info')}"
            log_html += f'<div class="log-entry {css}">[{entry["time"]}] {entry["msg"]}</div>'

        st.markdown(f"""
        <div style="background:#0d1117;border:1px solid #30363d;border-radius:8px;
                    padding:14px 16px;max-height:500px;overflow-y:auto;">
            {log_html}
        </div>
        """, unsafe_allow_html=True)

    if st.button("🗑 Clear logs"):
        with agent._lock:
            agent._state["logs"] = []
        st.rerun()


# ══════════════════ DATABASE TAB ═════════════════════════════════════════════
with tab_db:
    import sqlite3 as _sqlite3

    st.markdown('<div class="sec-hd">🗄️ SQLite Database Browser</div>', unsafe_allow_html=True)

    db_path = "ticketiq.db"
    if not __import__("os").path.exists(db_path):
        st.info("Database not created yet — start the agent to initialise it.")
    else:
        db_tab1, db_tab2, db_tab3 = st.tabs(["Tickets", "Logs", "Stats"])

        def _query(sql, params=()):
            conn = _sqlite3.connect(db_path)
            conn.row_factory = _sqlite3.Row
            rows = conn.execute(sql, params).fetchall()
            conn.close()
            return [dict(r) for r in rows]

        with db_tab1:
            col_s1, col_s2, col_s3 = st.columns(3)
            with col_s1:
                search = st.text_input("Search summary / sender", placeholder="keyword…", key="db_search")
            with col_s2:
                pri_filter = st.selectbox("Priority", ["All","Critical","High","Medium","Low"], key="db_pri")
            with col_s3:
                cat_filter = st.selectbox("Category", ["All","Hardware","Software","Network","Access","Other"], key="db_cat")

            sql = "SELECT * FROM tickets WHERE 1=1"
            params = []
            if search:
                sql += " AND (summary LIKE ? OR sender LIKE ?)"
                params += [f"%{search}%", f"%{search}%"]
            if pri_filter != "All":
                sql += " AND priority = ?"
                params.append(pri_filter)
            if cat_filter != "All":
                sql += " AND category = ?"
                params.append(cat_filter)
            sql += " ORDER BY created_at DESC"

            rows = _query(sql, params)
            if rows:
                df_db = __import__("pandas").DataFrame(rows)
                st.markdown(f'<div style="font-size:12px;color:#7d8590;margin-bottom:8px">{len(rows)} record(s)</div>', unsafe_allow_html=True)
                st.dataframe(df_db, width="stretch", hide_index=True)

                # Download
                csv_data = df_db.to_csv(index=False).encode()
                st.download_button("⬇️ Export CSV", data=csv_data, file_name="tickets.csv", mime="text/csv")
            else:
                st.info("No tickets match the filter.")

        with db_tab2:
            level_f = st.selectbox("Level", ["All","info","warning","error"], key="db_log_level")
            log_sql = "SELECT * FROM email_logs"
            log_params = []
            if level_f != "All":
                log_sql += " WHERE level = ?"
                log_params.append(level_f)
            log_sql += " ORDER BY id DESC LIMIT 500"
            log_rows = _query(log_sql, log_params)
            if log_rows:
                color_map_l = {"info": "#7d8590", "warning": "#d29922", "error": "#f85149"}
                log_html = ""
                for r in log_rows:
                    col = color_map_l.get(r.get("level","info"), "#7d8590")
                    log_html += f'<div style="font-family:IBM Plex Mono; font-size:12px; color:{col};">{r.get("msg","")}</div>'
                st.markdown(f'<div style="background:#0d1117;border:1px solid #30363d;border-radius:8px;padding:14px;max-height:450px;overflow-y:auto">{log_html}</div>', unsafe_allow_html=True)
            else:
                st.info("No logs yet.")

        with db_tab3:
            stat_rows = _query("SELECT key, value FROM stats")
            if stat_rows:
                c1,c2,c3,c4 = st.columns(4)
                stat_dict = {r["key"]: r["value"] for r in stat_rows}
                c1.metric("Total Emails",    stat_dict.get("total_emails", 0))
                c2.metric("Tickets Created", stat_dict.get("tickets_created", 0))
                c3.metric("No Action",       stat_dict.get("no_action", 0))
                c4.metric("Errors",          stat_dict.get("errors", 0))

                st.markdown("<br>", unsafe_allow_html=True)
                st.markdown('<div class="sec-hd">Raw stats table</div>', unsafe_allow_html=True)
                st.dataframe(__import__("pandas").DataFrame(stat_rows), width="stretch", hide_index=True)

                if st.button("🗑 Reset all stats", key="reset_stats"):
                    conn = _sqlite3.connect(db_path)
                    conn.execute("UPDATE stats SET value = 0")
                    conn.commit()
                    conn.close()
                    st.success("Stats reset.")
                    st.rerun()

# ── Auto-refresh ──────────────────────────────────────────────────────────────
if st.session_state["auto_refresh"]:
    time.sleep(30)
    st.rerun()