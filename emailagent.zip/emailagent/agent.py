"""
agent.py — Email-to-ServiceNow LangChain Agent
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Architecture:
  Each unread email is handed to a LangChain ReAct agent (create_react_agent).
  The agent has 5 tools it can call in any order and any number of times:

      1. search_existing_incidents  — semantic duplicate/follow-up check via LLM
      2. find_related_incidents     — semantic similarity ranking via LLM
      3. create_incident            — creates a new ServiceNow incident + saves to DB
      4. append_followup            — adds a work-note to an existing incident + updates DB
      5. dismiss_email              — marks email as no-action (spam / non-support)

  Gmail threadId is still checked first (100% reliable, no LLM needed).
  For any new thread, the agent reasons with tools instead of hard-coded branching.

Run: streamlit run app.py
"""

import os, json, re, base64, pickle, time, threading, logging, sqlite3, functools
from datetime import datetime, timedelta
from dotenv import load_dotenv

from langchain_nvidia_ai_endpoints import ChatNVIDIA
from langchain.tools import tool
from langchain.agents import create_react_agent, AgentExecutor
from langchain_core.prompts import PromptTemplate

from googleapiclient.discovery import build
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
import requests
from apscheduler.schedulers.background import BackgroundScheduler

load_dotenv()

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger(__name__)


# ══════════════════════════════════════════════════════════════════════════════
# RETRY HELPER  — handles 429 / transient errors with exponential backoff
# ══════════════════════════════════════════════════════════════════════════════
_RETRY_ATTEMPTS = 5          # max attempts before giving up
_RETRY_BASE_WAIT = 10        # seconds — doubles each attempt: 10, 20, 40, 80, 160
_RETRY_MAX_WAIT  = 120       # cap per sleep


def _is_rate_limit(exc: Exception) -> bool:
    msg = str(exc).lower()
    return "429" in msg or "too many requests" in msg or "rate limit" in msg


def _with_retry(fn, *args, label: str = "LLM call", **kwargs):
    """Call fn(*args, **kwargs) with exponential backoff on 429 errors."""
    for attempt in range(1, _RETRY_ATTEMPTS + 1):
        try:
            return fn(*args, **kwargs)
        except Exception as exc:
            if _is_rate_limit(exc) and attempt < _RETRY_ATTEMPTS:
                wait = min(_RETRY_BASE_WAIT * (2 ** (attempt - 1)), _RETRY_MAX_WAIT)
                log.warning(
                    f"[Retry] {label} — 429 rate limit (attempt {attempt}/{_RETRY_ATTEMPTS}). "
                    f"Waiting {wait}s…"
                )
                time.sleep(wait)
            else:
                raise  # non-429 error or final attempt — propagate

# ══════════════════════════════════════════════════════════════════════════════
# DATABASE
# ══════════════════════════════════════════════════════════════════════════════
DB_PATH = "ticketiq.db"


def init_db():
    db_existed = os.path.exists(DB_PATH)
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()

    c.execute("""
        CREATE TABLE IF NOT EXISTS tickets (
            id                 TEXT PRIMARY KEY,
            sys_id             TEXT,
            subject            TEXT,
            sender             TEXT,
            summary            TEXT,
            description        TEXT,
            category           TEXT,
            priority           TEXT,
            customer           TEXT,
            status             TEXT,
            sn_status          TEXT,
            body_preview       TEXT,
            created_at         TEXT,
            gmail_thread_id    TEXT,
            thread_reply_count        INTEGER DEFAULT 0,
            cross_thread_followup_count INTEGER DEFAULT 0,
            last_reply_at      TEXT,
            last_reply_subject TEXT,
            last_reply_preview TEXT,
            related_incidents   TEXT DEFAULT '[]'
        )
    """)

    for col, col_type in [
        ("gmail_thread_id",             "TEXT"),
        ("thread_reply_count",          "INTEGER DEFAULT 0"),
        ("cross_thread_followup_count", "INTEGER DEFAULT 0"),
        ("last_reply_at",               "TEXT"),
        ("last_reply_subject",          "TEXT"),
        ("last_reply_preview",          "TEXT"),
        ("related_incidents",           "TEXT DEFAULT '[]'"),
    ]:
        try:
            c.execute(f"ALTER TABLE tickets ADD COLUMN {col} {col_type}")
        except Exception:
            pass

    c.execute("""
        CREATE TABLE IF NOT EXISTS email_logs (
            id        INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT, level TEXT, message TEXT
        )
    """)
    c.execute("""
        CREATE TABLE IF NOT EXISTS stats (
            key TEXT PRIMARY KEY, value INTEGER DEFAULT 0
        )
    """)
    for key in ("total_emails", "tickets_created", "no_action", "followups", "errors"):
        c.execute("INSERT OR IGNORE INTO stats (key, value) VALUES (?, 0)", (key,))

    conn.commit()
    if db_existed:
        rows = c.execute(
            "SELECT gmail_thread_id FROM tickets WHERE gmail_thread_id IS NOT NULL AND gmail_thread_id != ''"
        ).fetchall()
        log.info(f"[DB] Existing DB — {len(rows)} tracked thread ID(s) loaded.")
    else:
        log.info("[DB] New database created at %s", DB_PATH)
    conn.close()


def db_save_ticket(ticket: dict):
    conn = sqlite3.connect(DB_PATH)
    conn.execute("""
        INSERT OR REPLACE INTO tickets
        (id, sys_id, subject, sender, summary, description, category,
         priority, customer, status, sn_status, body_preview, created_at,
         gmail_thread_id, thread_reply_count, related_incidents)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
    """, (
        ticket["id"], ticket.get("sys_id", ""), ticket["subject"], ticket["sender"],
        ticket["summary"], ticket["description"], ticket["category"], ticket["priority"],
        ticket["customer"], ticket["status"], ticket["sn_status"],
        ticket["body_preview"], ticket["created_at"],
        ticket.get("gmail_thread_id", ""), ticket.get("thread_reply_count", 0),
        json.dumps(ticket.get("related_incidents", [])),
    ))
    conn.commit()
    conn.close()


def db_find_by_thread(gmail_thread_id: str) -> dict | None:
    if not gmail_thread_id:
        return None
    # Check in-memory state first (catches same-batch duplicates before DB commit)
    with _lock:
        for t in _state["tickets"]:
            if t.get("gmail_thread_id") == gmail_thread_id:
                return t
    # Fall back to DB
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    row = conn.execute(
        "SELECT * FROM tickets WHERE gmail_thread_id = ? LIMIT 1", (gmail_thread_id,)
    ).fetchone()
    conn.close()
    return dict(row) if row else None


def db_all_tickets() -> list[dict]:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    rows = conn.execute("SELECT * FROM tickets ORDER BY created_at DESC").fetchall()
    conn.close()
    return [dict(r) for r in rows]


def db_append_followup(ticket_id: str, subject: str, body_preview: str, gmail_thread_id: str = "", cross_thread: bool = False):
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    conn = sqlite3.connect(DB_PATH)
    if cross_thread:
        conn.execute("""
            UPDATE tickets SET
                thread_reply_count        = thread_reply_count + 1,
                cross_thread_followup_count = cross_thread_followup_count + 1,
                last_reply_at      = ?,
                last_reply_subject = ?,
                last_reply_preview = ?
            WHERE id = ?
        """, (now, subject, body_preview[:300], ticket_id))
    else:
        conn.execute("""
            UPDATE tickets SET
                thread_reply_count = thread_reply_count + 1,
                last_reply_at      = ?,
                last_reply_subject = ?,
                last_reply_preview = ?,
                gmail_thread_id    = CASE
                    WHEN (gmail_thread_id IS NULL OR gmail_thread_id = '') AND ? != ''
                    THEN ? ELSE gmail_thread_id
                END
            WHERE id = ?
        """, (now, subject, body_preview[:300], gmail_thread_id, gmail_thread_id, ticket_id))
    conn.commit()
    conn.close()


def db_save_log(ts: str, level: str, msg: str):
    conn = sqlite3.connect(DB_PATH)
    conn.execute("INSERT INTO email_logs (timestamp, level, message) VALUES (?,?,?)", (ts, level, msg))
    conn.commit()
    conn.close()


def db_increment_stat(key: str):
    conn = sqlite3.connect(DB_PATH)
    conn.execute("UPDATE stats SET value = value + 1 WHERE key = ?", (key,))
    conn.commit()
    conn.close()


def db_load_all() -> dict:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    raw     = conn.execute("SELECT * FROM tickets ORDER BY created_at DESC").fetchall()
    tickets = []
    for r in raw:
        t = dict(r)
        try:
            t["related_incidents"] = json.loads(t.get("related_incidents") or "[]")
        except Exception:
            t["related_incidents"] = []
        tickets.append(t)
    stats   = {r["key"]: r["value"] for r in conn.execute("SELECT key, value FROM stats").fetchall()}
    logs    = [dict(r) for r in conn.execute(
        "SELECT timestamp as time, level, message as msg FROM email_logs ORDER BY id DESC LIMIT 200"
    ).fetchall()]
    conn.close()
    return {"tickets": tickets, "stats": stats, "logs": logs}


# ══════════════════════════════════════════════════════════════════════════════
# CONFIG + SHARED STATE
# ══════════════════════════════════════════════════════════════════════════════
SCOPES             = ["https://www.googleapis.com/auth/gmail.modify"]
POLL_INTERVAL_SECS = 120
MAX_EMAILS_PER_RUN = 10

SN_INSTANCE = os.getenv("SN_INSTANCE", "")
SN_USER     = os.getenv("SN_USER", "")
SN_PASSWORD = os.getenv("SN_PASSWORD", "")
SN_TABLE    = "incident"

PRIORITY_MAP = {"Critical": "1", "High": "2", "Medium": "3", "Low": "4"}
CATEGORY_MAP = {
    "Hardware": "hardware", "Software": "software",
    "Network":  "network",  "Access":   "inquiry", "Other": "inquiry",
}

_lock  = threading.Lock()
_state = {
    "tickets":           [],
    "last_checked":      None,
    "scheduler_running": False,
    "logs":              [],
    "stats": {
        "total_emails": 0, "tickets_created": 0,
        "no_action": 0,    "followups": 0, "errors": 0,
    },
}

# Email context injected before each agent run so tools can read it
_email_ctx: dict = {}


def get_state():
    with _lock:
        return json.loads(json.dumps(_state))


def _log(msg: str, level: str = "info"):
    ts = datetime.now().strftime("%H:%M:%S")
    getattr(log, level)(msg)
    with _lock:
        _state["logs"].insert(0, {"time": ts, "msg": msg, "level": level})
        _state["logs"] = _state["logs"][:100]
    try:
        db_save_log(ts, level, msg)
    except Exception:
        pass


# ══════════════════════════════════════════════════════════════════════════════
# LLM
# ══════════════════════════════════════════════════════════════════════════════
llm = ChatNVIDIA(
    model="qwen/qwen3-next-80b-a3b-instruct",
    api_key=os.getenv("NVIDIA_API_KEY"),
    temperature=0.2,
)


# ══════════════════════════════════════════════════════════════════════════════
# GMAIL
# ══════════════════════════════════════════════════════════════════════════════
def get_gmail_service():
    creds = None
    if os.path.exists("token.pickle"):
        with open("token.pickle", "rb") as f:
            creds = pickle.load(f)
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow  = InstalledAppFlow.from_client_secrets_file("credentials.json", SCOPES)
            creds = flow.run_local_server(port=0)
        with open("token.pickle", "wb") as f:
            pickle.dump(creds, f)
    return build("gmail", "v1", credentials=creds)


def fetch_unread_messages(service, max_results=MAX_EMAILS_PER_RUN):
    res = service.users().messages().list(
        userId="me", q="is:unread", maxResults=max_results
    ).execute()
    return res.get("messages", [])


def get_email_details(service, msg_id):
    msg     = service.users().messages().get(userId="me", id=msg_id, format="full").execute()
    headers = {h["name"]: h["value"] for h in msg["payload"].get("headers", [])}
    subject = headers.get("Subject", "(no subject)")
    sender  = headers.get("From", "unknown")
    thread_id = msg.get("threadId", "")

    payload = msg["payload"]
    parts   = payload.get("parts", [])
    body    = ""

    def _decode(data):
        return base64.urlsafe_b64decode(data + "==").decode("utf-8", errors="replace")

    if parts:
        for part in parts:
            if part.get("mimeType") == "text/plain":
                body = _decode(part["body"].get("data", ""))
                break
        if not body:
            body = _decode(parts[0]["body"].get("data", ""))
    else:
        body = _decode(payload["body"].get("data", ""))

    return subject, sender, body, thread_id


def mark_as_read(service, msg_id):
    service.users().messages().modify(
        userId="me", id=msg_id, body={"removeLabelIds": ["UNREAD"]}
    ).execute()


# ══════════════════════════════════════════════════════════════════════════════
# SERVICENOW
# ══════════════════════════════════════════════════════════════════════════════
def _sn_create(ticket_data: dict) -> dict:
    if not SN_INSTANCE or not SN_USER or not SN_PASSWORD:
        _log("ServiceNow not configured — using mock", "warning")
        return {
            "status": "mock",
            "sys_id": f"MOCK-{int(time.time())}",
            "number": f"INC{int(time.time()) % 100000:05d}",
        }
    url     = f"https://{SN_INSTANCE}/api/now/table/{SN_TABLE}"
    pri_int = int(PRIORITY_MAP.get(ticket_data.get("priority", "Medium"), "3"))
    payload = {
        "short_description": ticket_data.get("summary", "")[:160],
        "description":       ticket_data.get("description", ""),
        "urgency":           pri_int, "impact": pri_int,
        "category":          CATEGORY_MAP.get(ticket_data.get("category", "Other"), "inquiry"),
        "contact_type":      "email", "state": 1,
        "comments":          f"Auto-created by TicketIQ: {ticket_data.get('customer', '')}",
    }
    try:
        resp = requests.post(url, auth=(SN_USER, SN_PASSWORD),
                             headers={"Content-Type": "application/json", "Accept": "application/json"},
                             json=payload, timeout=15)
        if resp.status_code in (200, 201):
            r = resp.json().get("result", {})
            return {"status": "created", "sys_id": r.get("sys_id", ""), "number": r.get("number", "")}
        return {"status": "error", "message": f"HTTP {resp.status_code}"}
    except Exception as e:
        return {"status": "error", "message": str(e)}


def _sn_comment(sys_id: str, comment: str) -> bool:
    if not SN_INSTANCE or not SN_USER or not SN_PASSWORD or not sys_id:
        return False
    url = f"https://{SN_INSTANCE}/api/now/table/{SN_TABLE}/{sys_id}"
    try:
        resp = requests.patch(url, auth=(SN_USER, SN_PASSWORD),
                              headers={"Content-Type": "application/json", "Accept": "application/json"},
                              json={"work_notes": comment}, timeout=15)
        return resp.status_code in (200, 201)
    except Exception:
        return False


# ══════════════════════════════════════════════════════════════════════════════
# SEMANTIC SEARCH  (shared between tools and find_related_tickets)
# ══════════════════════════════════════════════════════════════════════════════
def _llm_semantic_search(query: str, candidates: list[dict]) -> list[dict]:
    """
    Ask the LLM to rank candidates by semantic similarity to query.
    Handles paraphrasing: "cannot login" == "unable to access account".
    Returns enriched ticket dicts with similarity_score and similarity_reason.
    """
    if not candidates:
        return []

    candidate_lines = "\n".join(
        f"[{t['id']}] {t.get('summary', '')} | {t.get('category', '')} | {t.get('description', '')[:120]}"
        for t in candidates
    )

    prompt = f"""You are an IT incident analyst. Identify which existing incidents are semantically
related to the new one — meaning the same or very similar IT problem, even if worded differently.

NEW INCIDENT:
{query}

EXISTING INCIDENTS:
{candidate_lines}

Return ONLY a valid JSON array. Each element:
  "id": incident ID string
  "similarity_score": float 0.0-1.0  (1.0 = identical issue)
  "reason": one sentence why they are related

Only include incidents with similarity_score >= 0.3. Return [] if none qualify.
Return ONLY the JSON array, no markdown, no other text."""

    try:
        raw = _with_retry(llm.invoke, [{"role": "user", "content": prompt}], label="semantic_search").content
        raw = re.sub(r"```(?:json)?|```", "", raw).strip()
        match = re.search(r"\[.*\]", raw, re.DOTALL)
        parsed = json.loads(match.group()) if match else []
        id_map = {t["id"]: t for t in candidates}
        enriched = []
        for r in parsed:
            base = dict(id_map.get(r.get("id", ""), {}))
            if base:
                base["similarity_score"]  = round(float(r.get("similarity_score", 0)), 2)
                base["similarity_reason"] = r.get("reason", "")
                enriched.append(base)
        enriched.sort(key=lambda x: x["similarity_score"], reverse=True)
        return enriched
    except Exception as e:
        _log(f"Semantic search error: {e}", "warning")
        return []


# ══════════════════════════════════════════════════════════════════════════════
# LANGCHAIN TOOLS
# ══════════════════════════════════════════════════════════════════════════════

@tool
def search_existing_incidents(query: str) -> str:
    """
    Semantically search all existing incidents to check if this email is a
    duplicate of an already-open incident. ALWAYS call this first before
    deciding to create a new incident.

    Input:  plain-English description of the issue from the email.
    Output: JSON list of matching incidents with id, summary, category,
            priority, similarity_score (0-1), and similarity_reason.
            Empty list means no duplicates found.
    """
    all_tickets = db_all_tickets()
    cutoff      = (datetime.now() - timedelta(days=30)).strftime("%Y-%m-%d %H:%M:%S")
    candidates  = [t for t in all_tickets if (t.get("created_at") or "") >= cutoff]
    results     = _llm_semantic_search(query, candidates)
    _log(f"search_existing_incidents: {len(results)} match(es) for '{query[:60]}'")
    return json.dumps(results, default=str)


@tool
def find_related_incidents(query: str) -> str:
    """
    Find incidents related to this issue in context — not necessarily duplicates,
    but incidents about the same system, component, or type of problem.
    Call this after creating or appending a ticket so the dashboard can show
    related incidents for operator awareness.

    Input:  description of the issue.
    Output: JSON list of related incidents with similarity_score and reason.
    """
    all_tickets = db_all_tickets()
    results     = _llm_semantic_search(query, all_tickets)
    _log(f"find_related_incidents: {len(results)} related found")
    return json.dumps(results, default=str)


@tool
def create_incident(ticket_json: str) -> str:
    """
    Create a new ServiceNow incident. Only call this AFTER confirming with
    search_existing_incidents that no duplicate (score >= 0.7) already exists.

    Input: a JSON string with these fields:
        summary     - One-line summary of the issue (max 160 chars)
        description - Detailed description of the problem
        category    - One of: Hardware, Software, Network, Access, Other
        priority    - One of: Critical, High, Medium, Low
                        Critical = outage / data-loss / production down
                        High     = major feature broken, blocking work
                        Medium   = degraded, workaround available
                        Low      = minor issue / general inquiry
        customer    - Sender name or email address

    Example input:
        {"summary": "VPN not connecting", "description": "User cannot connect to VPN after update",
         "category": "Network", "priority": "High", "customer": "john@example.com"}

    Returns: JSON with ticket_id, sys_id, status.
    """
    ctx = _email_ctx

    # Robustly parse — handle both raw JSON string and already-parsed dict
    try:
        if isinstance(ticket_json, dict):
            data = ticket_json
        else:
            cleaned = re.sub(r"```(?:json)?|```", "", str(ticket_json)).strip()
            data = json.loads(cleaned)
    except Exception:
        # Last resort: try to extract fields from malformed input
        data = {}

    # If the model stuffed everything into a nested key, unwrap it
    for key in ("ticket_json", "input", "data", "arguments"):
        if key in data and isinstance(data[key], (str, dict)):
            inner = data[key]
            if isinstance(inner, str):
                try:
                    inner = json.loads(inner)
                except Exception:
                    continue
            if isinstance(inner, dict) and "summary" in inner:
                data = inner
                break

    summary     = data.get("summary", "")
    description = data.get("description", "")
    category    = data.get("category", "Other")
    priority    = data.get("priority", "Medium")
    customer    = data.get("customer", ctx.get("sender", ""))

    if not summary:
        return json.dumps({"error": "summary is required — provide a valid JSON string"})

    # ── Thread-safety guard: never create a duplicate for an existing thread ──
    gmail_tid = ctx.get("gmail_thread_id", "")
    if gmail_tid:
        existing = db_find_by_thread(gmail_tid)
        if existing:
            _log(f"create_incident: thread {gmail_tid[:12]} already has incident {existing['id']} — appending instead", "warning")
            now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            reply_num = existing.get("thread_reply_count", 0) + 1
            note = f"[Follow-up #{reply_num}] {now_str}\nFrom: {ctx.get('sender','')}\n\n{ctx.get('body','')[:1200]}"
            _sn_comment(existing.get("sys_id", ""), note)
            db_append_followup(existing["id"], ctx.get("subject", ""), ctx.get("body", ""), gmail_tid)
            with _lock:
                for t in _state["tickets"]:
                    if t["id"] == existing["id"]:
                        t["thread_reply_count"] = reply_num
                        t["last_reply_at"]       = now_str
                        t["last_reply_subject"]  = ctx.get("subject", "")
                        t["last_reply_preview"]  = ctx.get("body", "")[:300]
                        break
            db_increment_stat("followups")
            with _lock:
                _state["stats"]["followups"] = _state["stats"].get("followups", 0) + 1
            return json.dumps({"ticket_id": existing["id"], "action": "followup_appended",
                               "reason": "thread already has an incident"})

    sn = _sn_create({"summary": summary, "description": description,
                     "category": category, "priority": priority, "customer": customer})
    ticket = {
        "id":                sn.get("number", f"LOCAL-{int(time.time())}"),
        "sys_id":            sn.get("sys_id", ""),
        "subject":           ctx.get("subject", ""),
        "sender":            ctx.get("sender", ""),
        "summary":           summary,
        "description":       description,
        "category":          category,
        "priority":          priority,
        "customer":          customer,
        "status":            sn.get("status", "unknown"),
        "sn_status":         sn.get("status", ""),
        "body_preview":      ctx.get("body", "")[:300],
        "created_at":        datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "gmail_thread_id":   ctx.get("gmail_thread_id", ""),
        "thread_reply_count": 0,
    }
    # Save ticket first (so it exists in DB before related search)
    ticket["related_incidents"] = []
    db_save_ticket(ticket)
    db_increment_stat("tickets_created")
    with _lock:
        _state["tickets"].insert(0, ticket)
        _state["stats"]["tickets_created"] += 1
    # Find related incidents — ticket already saved so it won't match itself
    all_existing = db_all_tickets()
    candidates   = [t for t in all_existing if t.get("id") != ticket["id"]]
    related      = _llm_semantic_search(
        f"{summary} — {description[:200]}", candidates
    )
    # Store only the fields needed for the UI panel
    related_slim = [
        {
            "id":               r.get("id", ""),
            "summary":          r.get("summary", ""),
            "category":         r.get("category", ""),
            "priority":         r.get("priority", ""),
            "sender":           r.get("sender", ""),
            "created_at":       r.get("created_at", ""),
            "sn_status":        r.get("sn_status", ""),
            "description":      r.get("description", ""),
            "body_preview":     r.get("body_preview", ""),
            "similarity_score": r.get("similarity_score", 0),
            "similarity_reason":r.get("similarity_reason", ""),
        }
        for r in related[:3]
    ]
    ticket["related_incidents"] = related_slim
    db_save_ticket(ticket)

    with _lock:
        _state["tickets"][0]["related_incidents"] = related_slim

    if related_slim:
        _log(f"Incident created: {ticket['id']} | {priority} | {category} | {len(related_slim)} related found")
    else:
        _log(f"Incident created: {ticket['id']} | {priority} | {category} | no related incidents")

    return json.dumps({
        "ticket_id":          ticket["id"],
        "sys_id":             ticket["sys_id"],
        "status":             sn.get("status"),
        "related_incidents":  related_slim,
    })


@tool
def append_followup(followup_json: str) -> str:
    """
    Append a follow-up note to an EXISTING incident when the email is an update,
    reply, or additional info for an already-open ticket.
    Use this when search_existing_incidents finds a match with score >= 0.7.

    Input: a JSON string with these fields:
        ticket_id - Incident number (e.g. INC00001)
        sys_id    - ServiceNow sys_id of the incident
        note      - Work-note content to add (extracted from email body)

    Example input:
        {"ticket_id": "INC00042", "sys_id": "abc123", "note": "User reports issue persists after restart"}

    Returns: JSON confirmation.
    """
    ctx = _email_ctx

    try:
        if isinstance(followup_json, dict):
            data = followup_json
        else:
            cleaned = re.sub(r"```(?:json)?|```", "", str(followup_json)).strip()
            data = json.loads(cleaned)
    except Exception:
        data = {}

    for key in ("followup_json", "input", "data", "arguments"):
        if key in data and isinstance(data[key], (str, dict)):
            inner = data[key]
            if isinstance(inner, str):
                try:
                    inner = json.loads(inner)
                except Exception:
                    continue
            if isinstance(inner, dict) and "ticket_id" in inner:
                data = inner
                break

    ticket_id = data.get("ticket_id", "")
    sys_id    = data.get("sys_id", "")
    note      = data.get("note", ctx.get("body", "")[:1200])

    if not ticket_id:
        return json.dumps({"error": "ticket_id is required — provide a valid JSON string"})

    now_str   = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    full_note = (
        f"[Follow-up] {now_str}\n"
        f"From: {ctx.get('sender', '')}\nSubject: {ctx.get('subject', '')}\n"
        f"{'─'*60}\n{note}"
    )
    sn_ok = _sn_comment(sys_id, full_note)
    db_append_followup(ticket_id, ctx.get("subject", ""), ctx.get("body", ""), ctx.get("gmail_thread_id", ""), cross_thread=True)
    with _lock:
        for t in _state["tickets"]:
            if t["id"] == ticket_id:
                t["thread_reply_count"] = t.get("thread_reply_count", 0) + 1
                t["last_reply_at"]      = now_str
                t["last_reply_subject"] = ctx.get("subject", "")
                t["last_reply_preview"] = ctx.get("body", "")[:300]
                break
    db_increment_stat("followups")
    with _lock:
        _state["stats"]["followups"] = _state["stats"].get("followups", 0) + 1
    _log(f"Follow-up appended to {ticket_id}" + (" | SN updated" if sn_ok else ""))
    return json.dumps({"ticket_id": ticket_id, "followup_added": True, "sn_updated": sn_ok})


@tool
def dismiss_email(reason: str) -> str:
    """
    Mark this email as no-action — do NOT create or update any incident.
    Use when the email is clearly not an IT support request:
    spam, newsletter, out-of-office reply, personal message, etc.

    Args:
        reason: Brief explanation of why this is not a support issue.
    Returns: JSON confirmation.
    """
    db_increment_stat("no_action")
    with _lock:
        _state["stats"]["no_action"] += 1
    _log(f"Email dismissed: {reason}")
    return json.dumps({"dismissed": True, "reason": reason})


# ══════════════════════════════════════════════════════════════════════════════
# LANGCHAIN REACT AGENT
# ══════════════════════════════════════════════════════════════════════════════
TOOLS = [search_existing_incidents, create_incident, dismiss_email]

AGENT_PROMPT = PromptTemplate.from_template(
"""You are an IT support agent that processes support emails and manages ServiceNow incidents.

You have access to the following tools:
{tools}

Available tool names: {tool_names}

DECISION PROCESS:
1. Call search_existing_incidents first with a plain-English description of the issue.
   Results are for AWARENESS only. Even if similar incidents exist, ALWAYS create a new incident
   because this email is a different Gmail thread = different user or separate occurrence.
2. Call create_incident to log the new ServiceNow incident.
3. Related incidents are automatically found and stored when create_incident runs — no extra step needed.
4. ONLY call dismiss_email instead if the email is clearly not an IT support request
   (spam, newsletter, out-of-office reply, personal message).

NEVER call append_followup — follow-ups are only triggered by Gmail thread ID matching, handled automatically before this agent runs.
Every email reaching this agent is always a new, separate incident.

PRIORITY:
Critical = outage / data-loss / production down
High     = major feature broken, blocking multiple users
Medium   = degraded performance, workaround available
Low      = minor issue / general inquiry

ACTION INPUT FORMAT:
create_incident takes a SINGLE JSON STRING:
  Action: create_incident
  Action Input: {{"summary": "...", "description": "...", "category": "Network", "priority": "High", "customer": "john@example.com"}}

search_existing_incidents takes plain English:
  Action: search_existing_incidents
  Action Input: User cannot connect to VPN after update

dismiss_email takes plain text:
  Action: dismiss_email
  Action Input: This is a newsletter, not a support request.

RESPONSE FORMAT:
Thought: <your reasoning>
Action: <tool name>
Action Input: <input>
Observation: <result>
... repeat as needed ...
Thought: Done.
Final Answer: <one sentence summary of what was done and why>

Email to process:
{input}

{agent_scratchpad}"""
)

_agent    = create_react_agent(llm, TOOLS, AGENT_PROMPT)
_executor = AgentExecutor(
    agent=_agent,
    tools=TOOLS,
    verbose=True,
    max_iterations=8,
    handle_parsing_errors=True,
    return_intermediate_steps=True,
)


# ══════════════════════════════════════════════════════════════════════════════
# PUBLIC: find_related_tickets  (called by app.py for the UI "Related" button)
# ══════════════════════════════════════════════════════════════════════════════
def find_related_tickets(target: dict, all_tickets: list[dict] = None, top_n: int = 3) -> list[dict]:
    """
    Returns related incidents stored on the ticket at creation time.
    No LLM call — instant read from the ticket's related_incidents field.
    """
    return (target.get("related_incidents") or [])[:top_n]


# ══════════════════════════════════════════════════════════════════════════════
# MAIN EMAIL PIPELINE
# ══════════════════════════════════════════════════════════════════════════════
def process_emails():
    _log("Checking for new emails…")
    with _lock:
        _state["last_checked"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    try:
        service  = get_gmail_service()
        messages = fetch_unread_messages(service)
        _log(f"Found {len(messages)} unread email(s)")
    except Exception as e:
        _log(f"Gmail error: {e}", "error")
        with _lock:
            _state["stats"]["errors"] += 1
        return

    for msg in messages:
        msg_id = msg["id"]
        try:
            subject, sender, body, gmail_tid = get_email_details(service, msg_id)
            _log(f"Processing: '{subject}' from {sender} [thread={gmail_tid[:12]}]")

            db_increment_stat("total_emails")
            with _lock:
                _state["stats"]["total_emails"] += 1

            # ── Fast path: exact Gmail thread ID = definite follow-up ─────────
            # threadId is 100% reliable — no LLM needed for same-thread replies.
            existing = db_find_by_thread(gmail_tid)
            if existing:
                reply_num = existing.get("thread_reply_count", 0) + 1
                _log(f"Thread match — follow-up #{reply_num} for {existing['id']}")
                now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                note = f"[Follow-up #{reply_num}] {now_str}\nFrom: {sender}\n\n{body[:1200]}"
                _sn_comment(existing.get("sys_id", ""), note)
                db_append_followup(existing["id"], subject, body, gmail_tid)
                with _lock:
                    for t in _state["tickets"]:
                        if t["id"] == existing["id"]:
                            t["thread_reply_count"] = reply_num
                            t["last_reply_at"]       = now_str
                            t["last_reply_subject"]  = subject
                            t["last_reply_preview"]  = body[:300]
                            break
                db_increment_stat("followups")
                with _lock:
                    _state["stats"]["followups"] = _state["stats"].get("followups", 0) + 1
                mark_as_read(service, msg_id)
                continue

            # ── Agent path: new thread — agent decides what to do ─────────────
            global _email_ctx
            _email_ctx = {
                "subject": subject, "sender": sender,
                "body": body, "gmail_thread_id": gmail_tid, "msg_id": msg_id,
            }

            email_text = (
                f"Subject: {subject}\nFrom: {sender}\n"
                f"Gmail Thread ID: {gmail_tid}\n\n{body[:2000]}"
            )

            try:
                result = _with_retry(
                    _executor.invoke,
                    {"input": email_text},
                    label=f"agent executor [{msg_id[:12]}]",
                )
                _log(f"Agent: {result.get('output', '')[:200]}")
            except Exception as e:
                if _is_rate_limit(e):
                    _log(f"Rate limit — skipping {msg_id} after retries, will retry next poll cycle", "warning")
                else:
                    _log(f"Agent error for {msg_id}: {e}", "error")
                db_increment_stat("errors")
                with _lock:
                    _state["stats"]["errors"] += 1

            mark_as_read(service, msg_id)

        except Exception as e:
            _log(f"Error processing {msg_id}: {e}", "error")
            with _lock:
                _state["stats"]["errors"] += 1


# ══════════════════════════════════════════════════════════════════════════════
# STARTUP + SCHEDULER
# ══════════════════════════════════════════════════════════════════════════════
def _seed_state_from_db():
    try:
        data = db_load_all()
        with _lock:
            _state["tickets"] = data["tickets"]
            _state["logs"]    = data["logs"]
            for k, v in data["stats"].items():
                _state["stats"][k] = v
        known = {t["gmail_thread_id"] for t in data["tickets"] if t.get("gmail_thread_id")}
        log.info(f"[Startup] {len(data['tickets'])} ticket(s), {len(known)} known thread ID(s).")
    except Exception as e:
        log.warning(f"Could not seed state from DB: {e}")


init_db()
_seed_state_from_db()

_scheduler = BackgroundScheduler(daemon=True)


def start_scheduler():
    if not _state["scheduler_running"]:
        _scheduler.add_job(
            process_emails, trigger="interval", seconds=POLL_INTERVAL_SECS,
            id="email_poll", next_run_time=datetime.now(),
        )
        _scheduler.start()
        with _lock:
            _state["scheduler_running"] = True
        _log(f"Agent started — polling every {POLL_INTERVAL_SECS}s")


def stop_scheduler():
    if _state["scheduler_running"]:
        _scheduler.shutdown(wait=False)
        with _lock:
            _state["scheduler_running"] = False
        _log("Agent stopped")


def trigger_now():
    threading.Thread(target=process_emails, daemon=True).start()